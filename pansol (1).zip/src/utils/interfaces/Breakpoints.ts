const breakPoints = {
  base: "95%",
  sm: "90%",
  lg: "85%",
  xl: "80%",
  "2xl": "75%",
};

export default breakPoints;
