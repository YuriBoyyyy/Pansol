function isEven(number: number) {
  if (number % 2 === 0) {
    return true;
  }
  return false;
}

export default isEven;
