import { Grid } from "@chakra-ui/react";

function Officials() {
  return (
    <Grid placeContent="center" h="100vh">
      {" "}
      Officials
    </Grid>
  );
}

export default Officials;
